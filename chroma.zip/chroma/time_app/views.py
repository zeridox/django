from django.shortcuts import render
from time import gmtime, strftime

def index(request):
    return render(request, "index.html", context)

context= {
    'time': strftime("%A %B-%-d-%Y %H:%M %-S %p", gmtime())
}