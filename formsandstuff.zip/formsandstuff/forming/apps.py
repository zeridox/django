from django.apps import AppConfig


class FormingConfig(AppConfig):
    name = 'forming'
